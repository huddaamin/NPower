﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TheLoopyPlanet
{
    class Program
    {
        static void Main(string[] args)
        {
            double loopyWeight = 0.0;
            int menuChoice = 0;
            do
            {

                Console.WriteLine("       Menu of Planets");//Drop Down Menu Of Planets
                Console.WriteLine("    ======= === ==========");
                Console.WriteLine("1. Jupiter   2. Mars   3. Mars");//Menu Choice
                Console.WriteLine("4. Neptune   3. Pluto  6. Saturn");
                Console.WriteLine("7. Uranus    8. Venus  9. <Quit>");



                Console.WriteLine("Enter Your Menu Choice = ");//Enter choice
                menuChoice = int.Parse(Console.ReadLine());

                Console.WriteLine("Enter Your Weight On Earth = ");//Enter weight
                double weightOnEarth = double.Parse(Console.ReadLine());

                switch (menuChoice)//Starts Switch statement for Menu Choice
                {

                    case 1:
                        loopyWeight = weightOnEarth * 2.64;
                        Console.WriteLine("Your new weight is: " + (string.Format("{0:#.#}", loopyWeight)));
                        break;
                    //Multiply your Weight
                    case 2:
                        loopyWeight = weightOnEarth * 0.38;
                        Console.WriteLine("Your new weight is: " + (string.Format("{0:#.#}", loopyWeight)));
                        break;
                    //Multiply your Weight
                    case 3:
                        loopyWeight = weightOnEarth * 0.37;
                        Console.WriteLine("Your new weight is: " + (string.Format("{0:#.#}", loopyWeight)));
                        break;
                    //Multiply your weight
                    case 4:
                        loopyWeight = weightOnEarth * 1.12;
                        Console.WriteLine("Your new weight is: " + (string.Format("{0:#.#}", loopyWeight)));
                        //Multiply your weight
                        break;
                    case 5:
                        loopyWeight = weightOnEarth * 0.04;
                        Console.WriteLine("Your new weight is: " + (string.Format("{0:#.#}", loopyWeight)));
                        //Multiply your weight
                        break;
                    case 6:
                        loopyWeight = weightOnEarth * 1.15;
                        Console.WriteLine("Your new weight is: " + (string.Format("{0:#.#}", loopyWeight)));
                        //Multiply your weight
                        break;
                    case 7:
                        loopyWeight = weightOnEarth * 1.15;
                        Console.WriteLine("Your new weight is: " + (string.Format("{0:#.#}", loopyWeight)));
                        //Multiply your weight
                        break;
                    case 8:
                        loopyWeight = weightOnEarth * 0.88;
                        Console.WriteLine("Your new weight is: " + (string.Format("{0:#.#}", loopyWeight)));
                        break;
                    case 9:
                        Console.WriteLine("Thanks for using TheLoopyPlanet Challenge          Have a Good Day");//Message to be print when press No.9
                        break;
                    default:
                        Console.WriteLine("Please enter valid number");
                        break;

                        Console.WriteLine(string.Format("{0:#.#}", loopyWeight));
                }
                } while (menuChoice != 9);//End the Loop

            }
            }                         
            
            
        }
    

